//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestCore.rc
//
#define IDS_PROJNAME                    100
#define IDR_CTEST                     101
#define IDR_CTESTOUTPUT               102
#define IDR_CTESTSUITECOLLECTION      103
#define IDR_CTESTSUITE                104
#define IDR_CTESTSUITEITEMCOLLECTION  105
#define IDR_CTESTSUITEITEM            106

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
