//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ClinivisionTest.rc
//
#define IDR_SRVR_INPLACE                4
#define IDR_SRVR_EMBEDDED               5
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDC_POINTER                     104
#define IDC_NODROP                      106
#define IDR_MAINFRAME                   128
#define IDR_CLINIVTYPE                  129
#define IDR_TESTSUITE_MENU              129
#define IDS_LOADINGTESTSUITES           129
#define IDI_TEST                        130
#define IDR_RESULTS_MENU                130
#define IDS_TESTSUITEINFOLOADED         130
#define IDB_TEST                        131
#define IDR_TEST_MENU                   131
#define IDS_LOGFILENAME                 131
#define IDS_TESTNAMEBEGIN               132
#define IDS_TESTNAMEEND                 133
#define IDS_TESTPASSED                  134
#define IDS_TESTFAILED                  135
#define IDB_FOLDER                      136
#define IDS_LOGFILENAMEKEY              136
#define IDB_OPENFOLDER                  137
#define IDS_LOGFILENAMEVALUE            137
#define IDB_TESTSUITE_STATE             138
#define IDS_APPREGISTRY                 138
#define IDS_TESTCOLLECTIONLOAD_FAILED   139
#define IDD_TESTSUITE                   140
#define IDD_OPTIONS                     141
#define IDC_TXT_NAME                    1000
#define IDC_TXT_RUNCOUNT                1001
#define IDC_TXT_NUMTESTRUNS             1002
#define IDC_TXT_LOGFILENAME             1002
#define IDC_BTN_SELECTFILE              1003
#define ID_CANCEL_EDIT_SRVR             32769
#define ID_INCREMENT_RUNCOUNT           32782
#define ID_DECREMENT_RUNCOUNT           32783
#define ID_RENAME_TESTORSUITE           32784
#define ID_NEW_TEST                     32786
#define ID_NEW_SUITE                    32787
#define ID_DELETE_TESTORSUITE           32788
#define ID_TESTSUITE_RUNTEST            32790
#define ID_CLEAR_RESULTS                32792
#define ID_VIEW_EXPANDTREE              32794
#define ID_VIEW_COLLAPSETREE            32795
#define ID_FILE_STOPTESTS               32798
#define ID_TOOLS_OPTIONS                32799
#define ID_TESTCOLLECTIONLOAD_FAILED    59142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32800
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
